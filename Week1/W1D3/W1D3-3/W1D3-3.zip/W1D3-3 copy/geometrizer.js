let calcCircumfrence = function(radius) {
    console.log("The circumference is " + (radius * 2 * Math.PI));
};

calcCircumfrence(4)

let calcArea = function(radius) {
    console.log('The area is ' + radius * radius * Math.PI);
}

calcArea(4)