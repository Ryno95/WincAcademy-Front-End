let calculateDogAge = function(puppyAge) {
    console.log('Your doggo is ' + puppyAge * 7 + ' years old in dog years!');
};
calculateDogAge(3)
calculateDogAge(7)
calculateDogAge(4)